﻿namespace 入梦工具箱
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.菜单 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清空ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.大图标ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.中图标ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.小图标ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除路径及文件toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.打开文件目录toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.透明度 = new System.Windows.Forms.TrackBar();
            this.imageList13 = new System.Windows.Forms.ImageList(this.components);
            this.imageList6 = new System.Windows.Forms.ImageList(this.components);
            this.imageList5 = new System.Windows.Forms.ImageList(this.components);
            this.imageList4 = new System.Windows.Forms.ImageList(this.components);
            this.imageList3 = new System.Windows.Forms.ImageList(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList21 = new System.Windows.Forms.ImageList(this.components);
            this.imageList20 = new System.Windows.Forms.ImageList(this.components);
            this.imageList19 = new System.Windows.Forms.ImageList(this.components);
            this.imageList18 = new System.Windows.Forms.ImageList(this.components);
            this.imageList12 = new System.Windows.Forms.ImageList(this.components);
            this.imageList11 = new System.Windows.Forms.ImageList(this.components);
            this.imageList10 = new System.Windows.Forms.ImageList(this.components);
            this.imageList9 = new System.Windows.Forms.ImageList(this.components);
            this.imageList8 = new System.Windows.Forms.ImageList(this.components);
            this.imageList7 = new System.Windows.Forms.ImageList(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label104 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.滑标 = new System.Windows.Forms.PictureBox();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.系统状态 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.语言选择框 = new System.Windows.Forms.ComboBox();
            this.JieShao = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.listView11 = new System.Windows.Forms.ListView();
            this.label28 = new System.Windows.Forms.Label();
            this.listView10 = new System.Windows.Forms.ListView();
            this.listView9 = new System.Windows.Forms.ListView();
            this.listView8 = new System.Windows.Forms.ListView();
            this.listView7 = new System.Windows.Forms.ListView();
            this.listView6 = new System.Windows.Forms.ListView();
            this.listView3 = new System.Windows.Forms.ListView();
            this.listView5 = new System.Windows.Forms.ListView();
            this.listView4 = new System.Windows.Forms.ListView();
            this.listView2 = new System.Windows.Forms.ListView();
            this.label20 = new System.Windows.Forms.Label();
            this.最小化托盘 = new System.Windows.Forms.PictureBox();
            this.关闭 = new System.Windows.Forms.PictureBox();
            this.最小化 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label94 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.label93 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label95 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.当前版本 = new System.Windows.Forms.Label();
            this.最新版本 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.窗口置顶 = new System.Windows.Forms.CheckBox();
            this.烤GPU = new System.Windows.Forms.CheckBox();
            this.烤CPU = new System.Windows.Forms.CheckBox();
            this.labl关机 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.CheckBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.一键双烤 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label98 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.label96 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label60 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.定时烤鸡 = new System.Windows.Forms.Timer(this.components);
            this.label83 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button25 = new System.Windows.Forms.Button();
            this.label105 = new System.Windows.Forms.Label();
            this.菜单.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.透明度)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.滑标)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.最小化托盘)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.关闭)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.最小化)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // 菜单
            // 
            this.菜单.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.菜单.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.删除ToolStripMenuItem,
            this.清空ToolStripMenuItem,
            this.大图标ToolStripMenuItem,
            this.中图标ToolStripMenuItem,
            this.小图标ToolStripMenuItem,
            this.删除路径及文件toolStripMenuItem1,
            this.打开文件目录toolStripMenuItem1});
            this.菜单.Name = "contextMenuStrip1";
            this.菜单.Size = new System.Drawing.Size(184, 172);
            this.菜单.Opening += new System.ComponentModel.CancelEventHandler(this.菜单_Opening);
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click_1);
            // 
            // 清空ToolStripMenuItem
            // 
            this.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem";
            this.清空ToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.清空ToolStripMenuItem.Text = "清空";
            this.清空ToolStripMenuItem.Click += new System.EventHandler(this.清空ToolStripMenuItem_Click);
            // 
            // 大图标ToolStripMenuItem
            // 
            this.大图标ToolStripMenuItem.Name = "大图标ToolStripMenuItem";
            this.大图标ToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.大图标ToolStripMenuItem.Text = "大图标";
            this.大图标ToolStripMenuItem.Click += new System.EventHandler(this.大图标ToolStripMenuItem_Click);
            // 
            // 中图标ToolStripMenuItem
            // 
            this.中图标ToolStripMenuItem.Name = "中图标ToolStripMenuItem";
            this.中图标ToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.中图标ToolStripMenuItem.Text = "中图标";
            this.中图标ToolStripMenuItem.Click += new System.EventHandler(this.中图标ToolStripMenuItem_Click);
            // 
            // 小图标ToolStripMenuItem
            // 
            this.小图标ToolStripMenuItem.Name = "小图标ToolStripMenuItem";
            this.小图标ToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.小图标ToolStripMenuItem.Text = "小图标";
            this.小图标ToolStripMenuItem.Click += new System.EventHandler(this.小图标ToolStripMenuItem_Click);
            // 
            // 删除路径及文件toolStripMenuItem1
            // 
            this.删除路径及文件toolStripMenuItem1.Name = "删除路径及文件toolStripMenuItem1";
            this.删除路径及文件toolStripMenuItem1.Size = new System.Drawing.Size(183, 24);
            this.删除路径及文件toolStripMenuItem1.Text = "删除路径及文件";
            this.删除路径及文件toolStripMenuItem1.Click += new System.EventHandler(this.删除路径及文件toolStripMenuItem1_Click);
            // 
            // 打开文件目录toolStripMenuItem1
            // 
            this.打开文件目录toolStripMenuItem1.Name = "打开文件目录toolStripMenuItem1";
            this.打开文件目录toolStripMenuItem1.Size = new System.Drawing.Size(183, 24);
            this.打开文件目录toolStripMenuItem1.Text = "打开文件目录";
            this.打开文件目录toolStripMenuItem1.Click += new System.EventHandler(this.打开文件目录toolStripMenuItem1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(589, 543);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 24);
            this.label3.TabIndex = 27;
            this.label3.Text = "透明度:";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(255, 321);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 30);
            this.button2.TabIndex = 59;
            this.button2.Text = "系统音频";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // 透明度
            // 
            this.透明度.LargeChange = 10;
            this.透明度.Location = new System.Drawing.Point(683, 540);
            this.透明度.Margin = new System.Windows.Forms.Padding(4);
            this.透明度.Maximum = 100;
            this.透明度.Minimum = 30;
            this.透明度.Name = "透明度";
            this.透明度.Size = new System.Drawing.Size(316, 56);
            this.透明度.TabIndex = 47;
            this.透明度.Value = 100;
            this.透明度.Scroll += new System.EventHandler(this.透明度_Scroll);
            // 
            // imageList13
            // 
            this.imageList13.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList13.ImageStream")));
            this.imageList13.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList13.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList6
            // 
            this.imageList6.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList6.ImageStream")));
            this.imageList6.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList6.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList5
            // 
            this.imageList5.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList5.ImageStream")));
            this.imageList5.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList5.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList4
            // 
            this.imageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList4.ImageStream")));
            this.imageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList4.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList3
            // 
            this.imageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList3.ImageStream")));
            this.imageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList3.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList21
            // 
            this.imageList21.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList21.ImageStream")));
            this.imageList21.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList21.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList20
            // 
            this.imageList20.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList20.ImageStream")));
            this.imageList20.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList20.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList19
            // 
            this.imageList19.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList19.ImageStream")));
            this.imageList19.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList19.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList18
            // 
            this.imageList18.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList18.ImageStream")));
            this.imageList18.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList18.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList12
            // 
            this.imageList12.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList12.ImageStream")));
            this.imageList12.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList12.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList11
            // 
            this.imageList11.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList11.ImageStream")));
            this.imageList11.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList11.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList10
            // 
            this.imageList10.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList10.ImageStream")));
            this.imageList10.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList10.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList9
            // 
            this.imageList9.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList9.ImageStream")));
            this.imageList9.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList9.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList8
            // 
            this.imageList8.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList8.ImageStream")));
            this.imageList8.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList8.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList7
            // 
            this.imageList7.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList7.ImageStream")));
            this.imageList7.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList7.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "入梦工具箱";
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.显示托盘);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel1.Controls.Add(this.label104);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.pictureBox13);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.滑标);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.pictureBox14);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox11);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox12);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.pictureBox16);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1255, 765);
            this.panel1.TabIndex = 45;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label104.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label104.Location = new System.Drawing.Point(67, 731);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(82, 24);
            this.label104.TabIndex = 132;
            this.label104.Text = "选项设置";
            this.label104.Click += new System.EventHandler(this.label104_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label81.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label81.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label81.Location = new System.Drawing.Point(21, 102);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(118, 24);
            this.label81.TabIndex = 96;
            this.label81.Text = "新版本可更新";
            this.label81.Click += new System.EventHandler(this.label81_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImage = global::入梦语音包.Properties.Resources._1;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Location = new System.Drawing.Point(25, 25);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(69, 69);
            this.pictureBox13.TabIndex = 95;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.pictureBox13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.pictureBox13.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label29.Location = new System.Drawing.Point(100, 70);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(55, 27);
            this.label29.TabIndex = 94;
            this.label29.Text = "V1.0";
            // 
            // 滑标
            // 
            this.滑标.BackColor = System.Drawing.Color.DodgerBlue;
            this.滑标.Location = new System.Drawing.Point(0, 139);
            this.滑标.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.滑标.Name = "滑标";
            this.滑标.Size = new System.Drawing.Size(5, 45);
            this.滑标.TabIndex = 67;
            this.滑标.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label27.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(67, 147);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 24);
            this.label27.TabIndex = 85;
            this.label27.Text = "硬件信息";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pictureBox14.Location = new System.Drawing.Point(0, 140);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(229, 45);
            this.pictureBox14.TabIndex = 84;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label16.Location = new System.Drawing.Point(100, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 27);
            this.label16.TabIndex = 81;
            this.label16.Text = "入梦工具箱";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(67, 684);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 24);
            this.label15.TabIndex = 79;
            this.label15.Text = "工具大全";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(67, 639);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 24);
            this.label14.TabIndex = 78;
            this.label14.Text = "自定工具";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(67, 595);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 24);
            this.label13.TabIndex = 77;
            this.label13.Text = "其他工具";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(67, 551);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 24);
            this.label12.TabIndex = 76;
            this.label12.Text = "烤机工具";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(67, 506);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 24);
            this.label11.TabIndex = 75;
            this.label11.Text = "外设工具";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(67, 463);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 24);
            this.label10.TabIndex = 74;
            this.label10.Text = "综合检测";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(67, 417);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 24);
            this.label9.TabIndex = 73;
            this.label9.Text = "屏幕工具";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(67, 373);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 24);
            this.label8.TabIndex = 72;
            this.label8.Text = "硬盘工具";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(67, 327);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 24);
            this.label7.TabIndex = 71;
            this.label7.Text = "显卡工具";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(67, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 24);
            this.label6.TabIndex = 70;
            this.label6.Text = "内存工具";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(67, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 24);
            this.label5.TabIndex = 69;
            this.label5.Text = "主板工具";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(67, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 24);
            this.label4.TabIndex = 68;
            this.label4.Text = "CPU工具";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.SystemColors.MenuBar;
            this.pictureBox9.Location = new System.Drawing.Point(0, 184);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(229, 45);
            this.pictureBox9.TabIndex = 66;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(0, 675);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(229, 45);
            this.pictureBox10.TabIndex = 65;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 229);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 45);
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(0, 541);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(229, 45);
            this.pictureBox5.TabIndex = 66;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(0, 274);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(229, 45);
            this.pictureBox2.TabIndex = 60;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(0, 631);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(229, 45);
            this.pictureBox11.TabIndex = 64;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(0, 317);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(229, 45);
            this.pictureBox4.TabIndex = 61;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(0, 363);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(229, 45);
            this.pictureBox3.TabIndex = 62;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(0, 586);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(229, 45);
            this.pictureBox12.TabIndex = 63;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(0, 407);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(229, 45);
            this.pictureBox8.TabIndex = 63;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(0, 453);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(229, 45);
            this.pictureBox7.TabIndex = 64;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(0, 497);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(229, 45);
            this.pictureBox6.TabIndex = 65;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.系统状态);
            this.panel2.Controls.Add(this.label97);
            this.panel2.Controls.Add(this.label85);
            this.panel2.Controls.Add(this.语言选择框);
            this.panel2.Controls.Add(this.JieShao);
            this.panel2.Controls.Add(this.listView1);
            this.panel2.Controls.Add(this.listView11);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.listView10);
            this.panel2.Controls.Add(this.listView9);
            this.panel2.Controls.Add(this.listView8);
            this.panel2.Controls.Add(this.listView7);
            this.panel2.Controls.Add(this.listView6);
            this.panel2.Controls.Add(this.listView3);
            this.panel2.Controls.Add(this.listView5);
            this.panel2.Controls.Add(this.listView4);
            this.panel2.Controls.Add(this.listView2);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.最小化托盘);
            this.panel2.Controls.Add(this.关闭);
            this.panel2.Controls.Add(this.最小化);
            this.panel2.Controls.Add(this.pictureBox15);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(229, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1027, 776);
            this.panel2.TabIndex = 58;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // 系统状态
            // 
            this.系统状态.AutoSize = true;
            this.系统状态.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.系统状态.ForeColor = System.Drawing.Color.Black;
            this.系统状态.Location = new System.Drawing.Point(476, 70);
            this.系统状态.Name = "系统状态";
            this.系统状态.Size = new System.Drawing.Size(38, 24);
            this.系统状态.TabIndex = 132;
            this.系统状态.Text = ".......";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("微软雅黑", 10.8F);
            this.label97.ForeColor = System.Drawing.Color.Black;
            this.label97.Location = new System.Drawing.Point(476, 97);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(50, 24);
            this.label97.TabIndex = 136;
            this.label97.Text = "..........";
            this.label97.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label97.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label97.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.ForeColor = System.Drawing.Color.Black;
            this.label85.Location = new System.Drawing.Point(852, 85);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(41, 24);
            this.label85.TabIndex = 135;
            this.label85.Text = "lag:";
            this.label85.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label85.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label85.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // 语言选择框
            // 
            this.语言选择框.BackColor = System.Drawing.Color.White;
            this.语言选择框.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.语言选择框.DropDownWidth = 60;
            this.语言选择框.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.语言选择框.FormattingEnabled = true;
            this.语言选择框.Location = new System.Drawing.Point(915, 82);
            this.语言选择框.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.语言选择框.Name = "语言选择框";
            this.语言选择框.Size = new System.Drawing.Size(88, 28);
            this.语言选择框.TabIndex = 134;
            this.语言选择框.TabStop = false;
            this.语言选择框.SelectedIndexChanged += new System.EventHandler(this.语言选择框_SelectedIndexChanged);
            // 
            // JieShao
            // 
            this.JieShao.AutoSize = true;
            this.JieShao.Font = new System.Drawing.Font("微软雅黑", 12.5F);
            this.JieShao.Location = new System.Drawing.Point(760, 65);
            this.JieShao.Name = "JieShao";
            this.JieShao.Size = new System.Drawing.Size(54, 28);
            this.JieShao.TabIndex = 133;
            this.JieShao.Text = "介绍";
            // 
            // listView1
            // 
            this.listView1.AllowDrop = true;
            this.listView1.BackColor = System.Drawing.Color.Black;
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.ContextMenuStrip = this.菜单;
            this.listView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView1.ForeColor = System.Drawing.Color.Black;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(828, 26);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(41, 46);
            this.listView1.TabIndex = 97;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.Visible = false;
            this.listView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
            this.listView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView1_DragEnter);
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // listView11
            // 
            this.listView11.AllowDrop = true;
            this.listView11.BackColor = System.Drawing.Color.Black;
            this.listView11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView11.ContextMenuStrip = this.菜单;
            this.listView11.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView11.ForeColor = System.Drawing.Color.Black;
            this.listView11.HideSelection = false;
            this.listView11.Location = new System.Drawing.Point(835, 4);
            this.listView11.Margin = new System.Windows.Forms.Padding(4);
            this.listView11.MultiSelect = false;
            this.listView11.Name = "listView11";
            this.listView11.Size = new System.Drawing.Size(44, 32);
            this.listView11.TabIndex = 1;
            this.listView11.UseCompatibleStateImageBehavior = false;
            this.listView11.Visible = false;
            this.listView11.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView11_DragDrop);
            this.listView11.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView11_DragEnter);
            this.listView11.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView11_MouseDoubleClick);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 10.8F);
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(158, 65);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(50, 24);
            this.label28.TabIndex = 95;
            this.label28.Text = "..........";
            this.label28.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label28.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // listView10
            // 
            this.listView10.AllowDrop = true;
            this.listView10.BackColor = System.Drawing.Color.Black;
            this.listView10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView10.ContextMenuStrip = this.菜单;
            this.listView10.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView10.ForeColor = System.Drawing.Color.Black;
            this.listView10.HideSelection = false;
            this.listView10.Location = new System.Drawing.Point(820, 25);
            this.listView10.Margin = new System.Windows.Forms.Padding(4);
            this.listView10.MultiSelect = false;
            this.listView10.Name = "listView10";
            this.listView10.Size = new System.Drawing.Size(44, 22);
            this.listView10.TabIndex = 1;
            this.listView10.UseCompatibleStateImageBehavior = false;
            this.listView10.Visible = false;
            this.listView10.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView10_DragDrop);
            this.listView10.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView10_DragEnter);
            this.listView10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView10_MouseClick);
            this.listView10.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView10_MouseDoubleClick);
            // 
            // listView9
            // 
            this.listView9.AllowDrop = true;
            this.listView9.BackColor = System.Drawing.Color.Black;
            this.listView9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView9.ContextMenuStrip = this.菜单;
            this.listView9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView9.ForeColor = System.Drawing.Color.Black;
            this.listView9.HideSelection = false;
            this.listView9.Location = new System.Drawing.Point(817, 12);
            this.listView9.Margin = new System.Windows.Forms.Padding(4);
            this.listView9.MultiSelect = false;
            this.listView9.Name = "listView9";
            this.listView9.Size = new System.Drawing.Size(52, 40);
            this.listView9.TabIndex = 1;
            this.listView9.UseCompatibleStateImageBehavior = false;
            this.listView9.Visible = false;
            this.listView9.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView9_DragDrop);
            this.listView9.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView9_DragEnter);
            this.listView9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView9_MouseClick);
            this.listView9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView9_MouseDoubleClick);
            // 
            // listView8
            // 
            this.listView8.AllowDrop = true;
            this.listView8.BackColor = System.Drawing.Color.Black;
            this.listView8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView8.ContextMenuStrip = this.菜单;
            this.listView8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView8.ForeColor = System.Drawing.Color.Black;
            this.listView8.HideSelection = false;
            this.listView8.Location = new System.Drawing.Point(835, 25);
            this.listView8.Margin = new System.Windows.Forms.Padding(4);
            this.listView8.MultiSelect = false;
            this.listView8.Name = "listView8";
            this.listView8.Size = new System.Drawing.Size(55, 22);
            this.listView8.TabIndex = 1;
            this.listView8.UseCompatibleStateImageBehavior = false;
            this.listView8.Visible = false;
            this.listView8.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView8_DragDrop);
            this.listView8.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView8_DragEnter);
            this.listView8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView8_MouseClick);
            this.listView8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView8_MouseDoubleClick);
            // 
            // listView7
            // 
            this.listView7.AllowDrop = true;
            this.listView7.BackColor = System.Drawing.Color.Black;
            this.listView7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView7.ContextMenuStrip = this.菜单;
            this.listView7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView7.ForeColor = System.Drawing.Color.Black;
            this.listView7.HideSelection = false;
            this.listView7.Location = new System.Drawing.Point(856, 32);
            this.listView7.Margin = new System.Windows.Forms.Padding(4);
            this.listView7.MultiSelect = false;
            this.listView7.Name = "listView7";
            this.listView7.Size = new System.Drawing.Size(44, 31);
            this.listView7.TabIndex = 1;
            this.listView7.UseCompatibleStateImageBehavior = false;
            this.listView7.Visible = false;
            this.listView7.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView7_DragDrop);
            this.listView7.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView7_DragEnter);
            this.listView7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView7_MouseClick);
            this.listView7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView7_MouseDoubleClick);
            // 
            // listView6
            // 
            this.listView6.AllowDrop = true;
            this.listView6.BackColor = System.Drawing.Color.Black;
            this.listView6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView6.ContextMenuStrip = this.菜单;
            this.listView6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView6.ForeColor = System.Drawing.Color.Black;
            this.listView6.HideSelection = false;
            this.listView6.Location = new System.Drawing.Point(843, 26);
            this.listView6.Margin = new System.Windows.Forms.Padding(4);
            this.listView6.MultiSelect = false;
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(57, 32);
            this.listView6.TabIndex = 1;
            this.listView6.UseCompatibleStateImageBehavior = false;
            this.listView6.Visible = false;
            this.listView6.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView6_DragDrop);
            this.listView6.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView6_DragEnter);
            this.listView6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView6_MouseClick);
            this.listView6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView6_MouseDoubleClick);
            // 
            // listView3
            // 
            this.listView3.AllowDrop = true;
            this.listView3.BackColor = System.Drawing.Color.Black;
            this.listView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView3.ContextMenuStrip = this.菜单;
            this.listView3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView3.ForeColor = System.Drawing.Color.Black;
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(820, 8);
            this.listView3.Margin = new System.Windows.Forms.Padding(4);
            this.listView3.MultiSelect = false;
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(44, 42);
            this.listView3.TabIndex = 1;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.Visible = false;
            this.listView3.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView3_DragDrop);
            this.listView3.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView3_DragEnter);
            this.listView3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView3_MouseClick);
            this.listView3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView3_MouseDoubleClick);
            // 
            // listView5
            // 
            this.listView5.AllowDrop = true;
            this.listView5.BackColor = System.Drawing.Color.Black;
            this.listView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView5.ContextMenuStrip = this.菜单;
            this.listView5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView5.ForeColor = System.Drawing.Color.Black;
            this.listView5.HideSelection = false;
            this.listView5.Location = new System.Drawing.Point(835, 16);
            this.listView5.Margin = new System.Windows.Forms.Padding(4);
            this.listView5.MultiSelect = false;
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(44, 42);
            this.listView5.TabIndex = 1;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.Visible = false;
            this.listView5.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView5_DragDrop);
            this.listView5.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView5_DragEnter);
            this.listView5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView5_MouseClick);
            this.listView5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView5_MouseDoubleClick);
            // 
            // listView4
            // 
            this.listView4.AllowDrop = true;
            this.listView4.BackColor = System.Drawing.Color.Black;
            this.listView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView4.ContextMenuStrip = this.菜单;
            this.listView4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView4.ForeColor = System.Drawing.Color.Black;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(825, 12);
            this.listView4.Margin = new System.Windows.Forms.Padding(4);
            this.listView4.MultiSelect = false;
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(44, 42);
            this.listView4.TabIndex = 1;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.Visible = false;
            this.listView4.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView4_DragDrop);
            this.listView4.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView4_DragEnter);
            this.listView4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView4_MouseClick);
            this.listView4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView4_MouseDoubleClick);
            // 
            // listView2
            // 
            this.listView2.AllowDrop = true;
            this.listView2.BackColor = System.Drawing.Color.Black;
            this.listView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView2.ContextMenuStrip = this.菜单;
            this.listView2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView2.ForeColor = System.Drawing.Color.Black;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(863, 12);
            this.listView2.Margin = new System.Windows.Forms.Padding(4);
            this.listView2.MultiSelect = false;
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(44, 45);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.Visible = false;
            this.listView2.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView2_DragDrop);
            this.listView2.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView2_DragEnter);
            this.listView2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView2_MouseClick);
            this.listView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView2_MouseDoubleClick);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(158, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 24);
            this.label20.TabIndex = 84;
            this.label20.Text = "lag:";
            this.label20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label20.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // 最小化托盘
            // 
            this.最小化托盘.BackgroundImage = global::入梦语音包.Properties.Resources.最小化托盘常规;
            this.最小化托盘.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.最小化托盘.ErrorImage = null;
            this.最小化托盘.Location = new System.Drawing.Point(915, 4);
            this.最小化托盘.Margin = new System.Windows.Forms.Padding(4);
            this.最小化托盘.Name = "最小化托盘";
            this.最小化托盘.Size = new System.Drawing.Size(32, 30);
            this.最小化托盘.TabIndex = 57;
            this.最小化托盘.TabStop = false;
            this.最小化托盘.Click += new System.EventHandler(this.最小化托盘_Click);
            this.最小化托盘.MouseEnter += new System.EventHandler(this.最小化托盘_MouseEnter);
            this.最小化托盘.MouseLeave += new System.EventHandler(this.最小化托盘_MouseLeave);
            // 
            // 关闭
            // 
            this.关闭.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("关闭.BackgroundImage")));
            this.关闭.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.关闭.Location = new System.Drawing.Point(987, 4);
            this.关闭.Margin = new System.Windows.Forms.Padding(4);
            this.关闭.Name = "关闭";
            this.关闭.Size = new System.Drawing.Size(32, 30);
            this.关闭.TabIndex = 38;
            this.关闭.TabStop = false;
            this.关闭.Click += new System.EventHandler(this.关闭_Click_1);
            this.关闭.MouseEnter += new System.EventHandler(this.常规_点燃);
            this.关闭.MouseLeave += new System.EventHandler(this.常规_离开);
            // 
            // 最小化
            // 
            this.最小化.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("最小化.BackgroundImage")));
            this.最小化.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.最小化.Location = new System.Drawing.Point(951, 4);
            this.最小化.Margin = new System.Windows.Forms.Padding(4);
            this.最小化.Name = "最小化";
            this.最小化.Size = new System.Drawing.Size(32, 30);
            this.最小化.TabIndex = 37;
            this.最小化.TabStop = false;
            this.最小化.Click += new System.EventHandler(this.最小化_Click_1);
            this.最小化.MouseEnter += new System.EventHandler(this.最小化_点燃);
            this.最小化.MouseLeave += new System.EventHandler(this.最小化_MouseLeave);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackgroundImage = global::入梦语音包.Properties.Resources._1;
            this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox15.Location = new System.Drawing.Point(37, 22);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(88, 88);
            this.pictureBox15.TabIndex = 92;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.pictureBox15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.pictureBox15.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(156, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 32);
            this.label19.TabIndex = 84;
            this.label19.Text = "..........";
            this.label19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label19.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label94);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.textBox5);
            this.panel4.Controls.Add(this.textBox4);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Controls.Add(this.textBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Location = new System.Drawing.Point(1, 139);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1023, 624);
            this.panel4.TabIndex = 94;
            this.panel4.Visible = false;
            this.panel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.Location = new System.Drawing.Point(756, 15);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(105, 24);
            this.label94.TabIndex = 131;
            this.label94.Text = "distinguish";
            this.label94.Click += new System.EventHandler(this.label94_Click);
            this.label94.MouseEnter += new System.EventHandler(this.label94_MouseEnter);
            this.label94.MouseLeave += new System.EventHandler(this.label94_MouseLeave);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(31, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 27);
            this.label22.TabIndex = 118;
            this.label22.Text = "分辨率:";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.CausesValidation = false;
            this.textBox6.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox6.Location = new System.Drawing.Point(133, 359);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(885, 34);
            this.textBox6.TabIndex = 130;
            this.textBox6.TabStop = false;
            this.textBox6.Click += new System.EventHandler(this.textBox6_DoubleClick);
            this.textBox6.MouseEnter += new System.EventHandler(this.textBox6_MouseEnter);
            this.textBox6.MouseLeave += new System.EventHandler(this.textBox6_MouseLeave);
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.White;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.CausesValidation = false;
            this.textBox9.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox9.Location = new System.Drawing.Point(133, 408);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox9.Size = new System.Drawing.Size(885, 206);
            this.textBox9.TabIndex = 129;
            this.textBox9.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(31, 408);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(50, 24);
            this.label36.TabIndex = 128;
            this.label36.Text = "分区:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(31, 358);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(57, 27);
            this.label31.TabIndex = 125;
            this.label31.Text = "网卡:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(31, 314);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(57, 27);
            this.label32.TabIndex = 124;
            this.label32.Text = "声卡:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(31, 269);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(57, 27);
            this.label30.TabIndex = 123;
            this.label30.Text = "硬盘:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(31, 225);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 27);
            this.label26.TabIndex = 122;
            this.label26.Text = "显卡:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(31, 180);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 27);
            this.label25.TabIndex = 121;
            this.label25.Text = "主板:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(31, 136);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 27);
            this.label24.TabIndex = 120;
            this.label24.Text = "内存:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(31, 90);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 27);
            this.label23.TabIndex = 119;
            this.label23.Text = "处理器:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(876, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 24);
            this.label2.TabIndex = 117;
            this.label2.Text = "......";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            this.label2.MouseEnter += new System.EventHandler(this.label2_MouseEnter);
            this.label2.MouseLeave += new System.EventHandler(this.label2_MouseLeave);
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.White;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.CausesValidation = false;
            this.textBox8.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8.Location = new System.Drawing.Point(133, 269);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(885, 34);
            this.textBox8.TabIndex = 116;
            this.textBox8.TabStop = false;
            this.textBox8.Click += new System.EventHandler(this.textBox8_DoubleClick);
            this.textBox8.MouseEnter += new System.EventHandler(this.textBox8_MouseEnter);
            this.textBox8.MouseLeave += new System.EventHandler(this.textBox8_MouseLeave);
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.CausesValidation = false;
            this.textBox7.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(133, 314);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(885, 34);
            this.textBox7.TabIndex = 115;
            this.textBox7.TabStop = false;
            this.textBox7.Click += new System.EventHandler(this.textBox7_DoubleClick);
            this.textBox7.MouseEnter += new System.EventHandler(this.textBox7_MouseEnter);
            this.textBox7.MouseLeave += new System.EventHandler(this.textBox7_MouseLeave);
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.CausesValidation = false;
            this.textBox5.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(133, 224);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(885, 34);
            this.textBox5.TabIndex = 113;
            this.textBox5.TabStop = false;
            this.textBox5.Click += new System.EventHandler(this.textBox5_DoubleClick);
            this.textBox5.MouseEnter += new System.EventHandler(this.textBox5_MouseEnter);
            this.textBox5.MouseLeave += new System.EventHandler(this.textBox5_MouseLeave);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.CausesValidation = false;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(133, 180);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(885, 34);
            this.textBox4.TabIndex = 112;
            this.textBox4.TabStop = false;
            this.textBox4.Click += new System.EventHandler(this.textBox4_DoubleClick);
            this.textBox4.MouseEnter += new System.EventHandler(this.textBox4_MouseEnter);
            this.textBox4.MouseLeave += new System.EventHandler(this.textBox4_MouseLeave);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.CausesValidation = false;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(133, 136);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(885, 34);
            this.textBox3.TabIndex = 111;
            this.textBox3.TabStop = false;
            this.textBox3.Click += new System.EventHandler(this.textBox3_DoubleClick);
            this.textBox3.MouseEnter += new System.EventHandler(this.textBox3_MouseEnter);
            this.textBox3.MouseLeave += new System.EventHandler(this.textBox3_MouseLeave);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.CausesValidation = false;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(133, 90);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(885, 34);
            this.textBox2.TabIndex = 110;
            this.textBox2.TabStop = false;
            this.textBox2.Click += new System.EventHandler(this.textBox2_DoubleClick);
            this.textBox2.MouseEnter += new System.EventHandler(this.textBox2_MouseEnter);
            this.textBox2.MouseLeave += new System.EventHandler(this.textBox2_MouseLeave);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.CausesValidation = false;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(133, 46);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(885, 34);
            this.textBox1.TabIndex = 1;
            this.textBox1.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(0, 720);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(229, 45);
            this.pictureBox16.TabIndex = 97;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label93.Location = new System.Drawing.Point(84, 1);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(83, 24);
            this.label93.TabIndex = 133;
            this.label93.Text = "Detailed";
            this.label93.Visible = false;
            this.label93.Click += new System.EventHandler(this.label93_Click);
            this.label93.MouseEnter += new System.EventHandler(this.label93_MouseEnter);
            this.label93.MouseLeave += new System.EventHandler(this.label93_MouseLeave);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.textBox15);
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Controls.Add(this.textBox14);
            this.panel12.Location = new System.Drawing.Point(3361, 141);
            this.panel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1091, 632);
            this.panel12.TabIndex = 132;
            this.panel12.TabStop = true;
            this.panel12.Visible = false;
            this.panel12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.White;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.CausesValidation = false;
            this.textBox15.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox15.Location = new System.Drawing.Point(895, 502);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox15.Size = new System.Drawing.Size(193, 128);
            this.textBox15.TabIndex = 134;
            this.textBox15.TabStop = false;
            this.textBox15.Visible = false;
            this.textBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.textBox15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.textBox15.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.label93);
            this.panel13.Controls.Add(this.label95);
            this.panel13.Controls.Add(this.label103);
            this.panel13.Location = new System.Drawing.Point(643, 2);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(384, 30);
            this.panel13.TabIndex = 135;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(179, 1);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(73, 24);
            this.label95.TabIndex = 135;
            this.label95.Text = "Default";
            this.label95.Click += new System.EventHandler(this.label95_Click);
            this.label95.MouseEnter += new System.EventHandler(this.label95_MouseEnter);
            this.label95.MouseLeave += new System.EventHandler(this.label95_MouseLeave);
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label103.Location = new System.Drawing.Point(263, 1);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(52, 24);
            this.label103.TabIndex = 117;
            this.label103.Text = "copy";
            this.label103.Click += new System.EventHandler(this.label103_Click);
            this.label103.MouseEnter += new System.EventHandler(this.label103_MouseEnter);
            this.label103.MouseLeave += new System.EventHandler(this.labe103_MouseLeave);
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.White;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.CausesValidation = false;
            this.textBox14.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox14.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.textBox14.Location = new System.Drawing.Point(53, 35);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(973, 560);
            this.textBox14.TabIndex = 132;
            this.textBox14.TabStop = false;
            this.textBox14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.textBox14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.textBox14.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(1269, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 24);
            this.label18.TabIndex = 83;
            this.label18.Text = "admin:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.label47);
            this.panel5.Controls.Add(this.label46);
            this.panel5.Controls.Add(this.label44);
            this.panel5.Controls.Add(this.label45);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Controls.Add(this.label38);
            this.panel5.Controls.Add(this.label39);
            this.panel5.Controls.Add(this.label40);
            this.panel5.Controls.Add(this.label41);
            this.panel5.Controls.Add(this.label42);
            this.panel5.Controls.Add(this.label43);
            this.panel5.Location = new System.Drawing.Point(1085, 934);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1015, 610);
            this.panel5.TabIndex = 98;
            this.panel5.Visible = false;
            this.panel5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(136, 505);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(39, 27);
            this.label47.TabIndex = 132;
            this.label47.Text = "L3:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(136, 460);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(39, 27);
            this.label46.TabIndex = 131;
            this.label46.Text = "L2:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(136, 416);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 27);
            this.label44.TabIndex = 130;
            this.label44.Text = "制造商:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.White;
            this.label45.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(940, 5);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(46, 24);
            this.label45.TabIndex = 129;
            this.label45.Text = "返回";
            this.label45.Click += new System.EventHandler(this.label45_Click_1);
            this.label45.MouseEnter += new System.EventHandler(this.label45_MouseEnter);
            this.label45.MouseLeave += new System.EventHandler(this.label45_MouseLeave);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(136, 238);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(50, 24);
            this.label35.TabIndex = 128;
            this.label35.Text = "架构:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(136, 371);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 27);
            this.label37.TabIndex = 125;
            this.label37.Text = "虚拟化:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(136, 192);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(57, 27);
            this.label38.TabIndex = 124;
            this.label38.Text = "主频:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(136, 326);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(57, 27);
            this.label39.TabIndex = 123;
            this.label39.Text = "描述:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(136, 282);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(38, 27);
            this.label40.TabIndex = 122;
            this.label40.Text = "ID:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(136, 148);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(57, 27);
            this.label41.TabIndex = 121;
            this.label41.Text = "线程:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(136, 102);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(57, 27);
            this.label42.TabIndex = 120;
            this.label42.Text = "核心:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(136, 59);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(77, 27);
            this.label43.TabIndex = 119;
            this.label43.Text = "处理器:";
            // 
            // 当前版本
            // 
            this.当前版本.AutoSize = true;
            this.当前版本.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.当前版本.ForeColor = System.Drawing.Color.Black;
            this.当前版本.Location = new System.Drawing.Point(73, 585);
            this.当前版本.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.当前版本.Name = "当前版本";
            this.当前版本.Size = new System.Drawing.Size(48, 24);
            this.当前版本.TabIndex = 86;
            this.当前版本.Text = "V1.0";
            // 
            // 最新版本
            // 
            this.最新版本.AutoSize = true;
            this.最新版本.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.最新版本.ForeColor = System.Drawing.Color.Black;
            this.最新版本.Location = new System.Drawing.Point(265, 585);
            this.最新版本.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.最新版本.Name = "最新版本";
            this.最新版本.Size = new System.Drawing.Size(48, 24);
            this.最新版本.TabIndex = 28;
            this.最新版本.Text = "V1.0";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.checkBox2);
            this.panel3.Controls.Add(this.label91);
            this.panel3.Controls.Add(this.label80);
            this.panel3.Controls.Add(this.label79);
            this.panel3.Controls.Add(this.label34);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.当前版本);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Controls.Add(this.窗口置顶);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.最新版本);
            this.panel3.Controls.Add(this.透明度);
            this.panel3.Location = new System.Drawing.Point(2309, 141);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1028, 624);
            this.panel3.TabIndex = 60;
            this.panel3.Visible = false;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.checkBox2.Location = new System.Drawing.Point(426, 543);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(104, 28);
            this.checkBox2.TabIndex = 157;
            this.checkBox2.Text = "插件识别";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.BackColor = System.Drawing.Color.White;
            this.label91.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label91.ForeColor = System.Drawing.Color.Black;
            this.label91.Location = new System.Drawing.Point(513, 585);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(146, 24);
            this.label91.TabIndex = 155;
            this.label91.Text = "Q群:957997089";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.White;
            this.label80.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label80.ForeColor = System.Drawing.Color.Black;
            this.label80.Location = new System.Drawing.Point(122, 26);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(92, 27);
            this.label80.TabIndex = 132;
            this.label80.Text = "最新消息";
            this.label80.Visible = false;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.White;
            this.label79.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label79.ForeColor = System.Drawing.Color.Black;
            this.label79.Location = new System.Drawing.Point(890, 585);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(44, 24);
            this.label79.TabIndex = 102;
            this.label79.Text = "bibi";
            this.label79.Click += new System.EventHandler(this.label79_Click);
            this.label79.MouseEnter += new System.EventHandler(this.label79_MouseEnter);
            this.label79.MouseLeave += new System.EventHandler(this.label79_MouseLeave);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(723, 585);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(46, 24);
            this.label34.TabIndex = 101;
            this.label34.Text = "更新";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            this.label34.MouseEnter += new System.EventHandler(this.labe34_MouseEnter);
            this.label34.MouseLeave += new System.EventHandler(this.label34_MouseLeave);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(779, 585);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 24);
            this.label21.TabIndex = 99;
            this.label21.Text = "官网";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            this.label21.MouseEnter += new System.EventHandler(this.label21_MouseEnter);
            this.label21.MouseLeave += new System.EventHandler(this.label21_MouseLeave);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(834, 585);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 24);
            this.label17.TabIndex = 98;
            this.label17.Text = "反馈";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            this.label17.MouseEnter += new System.EventHandler(this.label17_MouseEnter);
            this.label17.MouseLeave += new System.EventHandler(this.label17_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(941, 585);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 93;
            this.label1.Text = "初始化";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            this.label1.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.label1.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.checkBox1.Location = new System.Drawing.Point(226, 543);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(144, 28);
            this.checkBox1.TabIndex = 60;
            this.checkBox1.Text = "F12显示/隐藏";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // 窗口置顶
            // 
            this.窗口置顶.AutoSize = true;
            this.窗口置顶.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.窗口置顶.Location = new System.Drawing.Point(77, 541);
            this.窗口置顶.Margin = new System.Windows.Forms.Padding(4);
            this.窗口置顶.Name = "窗口置顶";
            this.窗口置顶.Size = new System.Drawing.Size(104, 28);
            this.窗口置顶.TabIndex = 46;
            this.窗口置顶.Text = "窗口置顶";
            this.窗口置顶.UseVisualStyleBackColor = true;
            this.窗口置顶.CheckedChanged += new System.EventHandler(this.窗口置顶_CheckedChanged);
            // 
            // 烤GPU
            // 
            this.烤GPU.AutoSize = true;
            this.烤GPU.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.烤GPU.Location = new System.Drawing.Point(372, 233);
            this.烤GPU.Name = "烤GPU";
            this.烤GPU.Size = new System.Drawing.Size(96, 31);
            this.烤GPU.TabIndex = 219;
            this.烤GPU.TabStop = false;
            this.烤GPU.Text = "烤GPU";
            this.烤GPU.UseVisualStyleBackColor = true;
            this.烤GPU.CheckedChanged += new System.EventHandler(this.烤GPU_CheckedChanged);
            // 
            // 烤CPU
            // 
            this.烤CPU.AutoSize = true;
            this.烤CPU.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.烤CPU.Location = new System.Drawing.Point(256, 233);
            this.烤CPU.Name = "烤CPU";
            this.烤CPU.Size = new System.Drawing.Size(94, 31);
            this.烤CPU.TabIndex = 218;
            this.烤CPU.TabStop = false;
            this.烤CPU.Text = "烤CPU";
            this.烤CPU.UseVisualStyleBackColor = true;
            this.烤CPU.CheckedChanged += new System.EventHandler(this.烤CPU_CheckedChanged);
            // 
            // labl关机
            // 
            this.labl关机.AutoSize = true;
            this.labl关机.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labl关机.Location = new System.Drawing.Point(131, 179);
            this.labl关机.Name = "labl关机";
            this.labl关机.Size = new System.Drawing.Size(92, 27);
            this.labl关机.TabIndex = 216;
            this.labl关机.Text = "剩余时间";
            this.labl关机.Visible = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButton4.Location = new System.Drawing.Point(489, 233);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(94, 31);
            this.radioButton4.TabIndex = 217;
            this.radioButton4.TabStop = false;
            this.radioButton4.Text = "倒计时";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59"});
            this.comboBox4.Location = new System.Drawing.Point(763, 236);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(45, 23);
            this.comboBox4.TabIndex = 212;
            this.comboBox4.Text = "0";
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59"});
            this.comboBox5.Location = new System.Drawing.Point(679, 236);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(46, 23);
            this.comboBox5.TabIndex = 211;
            this.comboBox5.Text = "15";
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.comboBox6.Location = new System.Drawing.Point(593, 236);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(48, 23);
            this.comboBox6.TabIndex = 210;
            this.comboBox6.Text = "0";
            this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.Location = new System.Drawing.Point(814, 235);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(32, 27);
            this.label100.TabIndex = 215;
            this.label100.Text = "秒";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label101.Location = new System.Drawing.Point(731, 234);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(32, 27);
            this.label101.TabIndex = 214;
            this.label101.Text = "分";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.Location = new System.Drawing.Point(647, 235);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(32, 27);
            this.label102.TabIndex = 213;
            this.label102.Text = "时";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label99.Location = new System.Drawing.Point(76, 233);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(50, 24);
            this.label99.TabIndex = 170;
            this.label99.Text = "快捷:";
            // 
            // 一键双烤
            // 
            this.一键双烤.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.一键双烤.Location = new System.Drawing.Point(136, 231);
            this.一键双烤.Margin = new System.Windows.Forms.Padding(4);
            this.一键双烤.Name = "一键双烤";
            this.一键双烤.Size = new System.Drawing.Size(110, 30);
            this.一键双烤.TabIndex = 167;
            this.一键双烤.Text = "一键烤机";
            this.一键双烤.UseVisualStyleBackColor = true;
            this.一键双烤.Click += new System.EventHandler(this.一键双烤_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(255, 479);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 30);
            this.button5.TabIndex = 166;
            this.button5.Text = "磁盘管理";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(136, 479);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(110, 30);
            this.button16.TabIndex = 165;
            this.button16.Text = "设备管理器";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label98.Location = new System.Drawing.Point(76, 323);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(50, 24);
            this.label98.TabIndex = 164;
            this.label98.Text = "音频:";
            // 
            // button27
            // 
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(136, 441);
            this.button27.Margin = new System.Windows.Forms.Padding(4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(110, 30);
            this.button27.TabIndex = 158;
            this.button27.Text = "桌面图标";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(136, 365);
            this.button26.Margin = new System.Windows.Forms.Padding(4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(110, 30);
            this.button26.TabIndex = 156;
            this.button26.Text = "检测激活";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label96.Location = new System.Drawing.Point(76, 367);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(50, 24);
            this.label96.TabIndex = 154;
            this.label96.Text = "系统:";
            // 
            // button24
            // 
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(489, 403);
            this.button24.Margin = new System.Windows.Forms.Padding(4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(110, 30);
            this.button24.TabIndex = 152;
            this.button24.Text = "屏保";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(728, 365);
            this.button23.Margin = new System.Windows.Forms.Padding(4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(110, 30);
            this.button23.TabIndex = 151;
            this.button23.Text = "防火墙";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(255, 365);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(110, 30);
            this.button22.TabIndex = 150;
            this.button22.Text = "系统属性";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(728, 403);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(110, 30);
            this.button21.TabIndex = 149;
            this.button21.Text = "区域";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(728, 441);
            this.button20.Margin = new System.Windows.Forms.Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(110, 30);
            this.button20.TabIndex = 148;
            this.button20.Text = "打印机";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(372, 365);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(110, 30);
            this.button19.TabIndex = 147;
            this.button19.Text = "电源管理";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(489, 441);
            this.button18.Margin = new System.Windows.Forms.Padding(4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(110, 30);
            this.button18.TabIndex = 146;
            this.button18.Text = "键盘属性";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(372, 441);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(110, 30);
            this.button17.TabIndex = 145;
            this.button17.Text = "系统字体";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button15
            // 
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(609, 403);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(110, 30);
            this.button15.TabIndex = 143;
            this.button15.Text = "电脑时间";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(255, 441);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(110, 30);
            this.button14.TabIndex = 142;
            this.button14.Text = "我的文档";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label92.Location = new System.Drawing.Point(76, 279);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(50, 24);
            this.label92.TabIndex = 141;
            this.label92.Text = "窗口:";
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(372, 275);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(110, 30);
            this.button13.TabIndex = 140;
            this.button13.Text = "显示任务栏";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(255, 275);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(110, 30);
            this.button12.TabIndex = 139;
            this.button12.Text = "隐藏任务栏";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(489, 365);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(110, 30);
            this.button11.TabIndex = 137;
            this.button11.Text = "注册表";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(609, 365);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(110, 30);
            this.button10.TabIndex = 136;
            this.button10.Text = "事件查看器";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.White;
            this.label90.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label90.Location = new System.Drawing.Point(2184, 49);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(50, 24);
            this.label90.TabIndex = 135;
            this.label90.Text = "面板:";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.White;
            this.label89.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label89.Location = new System.Drawing.Point(2184, 103);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(50, 24);
            this.label89.TabIndex = 134;
            this.label89.Text = "设备:";
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(136, 321);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(111, 30);
            this.button9.TabIndex = 133;
            this.button9.Text = "声卡检测";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(372, 321);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(110, 30);
            this.button8.TabIndex = 103;
            this.button8.Text = "播放静音";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(136, 403);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(110, 30);
            this.button7.TabIndex = 100;
            this.button7.Text = "任务管理器";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(372, 403);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(110, 30);
            this.button6.TabIndex = 97;
            this.button6.Text = "卸载软件";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(609, 441);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 30);
            this.button4.TabIndex = 95;
            this.button4.Text = "鼠标属性";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(255, 404);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 30);
            this.button3.TabIndex = 94;
            this.button3.Text = "控制面板";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1355, 19);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 30);
            this.button1.TabIndex = 100;
            this.button1.Text = "自定义列表";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.label50);
            this.panel6.Controls.Add(this.label51);
            this.panel6.Controls.Add(this.label52);
            this.panel6.Controls.Add(this.label53);
            this.panel6.Controls.Add(this.label54);
            this.panel6.Controls.Add(this.label55);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.label58);
            this.panel6.Controls.Add(this.label59);
            this.panel6.Location = new System.Drawing.Point(1181, 829);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1015, 610);
            this.panel6.TabIndex = 127;
            this.panel6.Visible = false;
            this.panel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(136, 359);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(72, 27);
            this.label50.TabIndex = 130;
            this.label50.Text = "控制器";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(940, 5);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(46, 24);
            this.label51.TabIndex = 129;
            this.label51.Text = "返回";
            this.label51.Click += new System.EventHandler(this.label51_Click);
            this.label51.MouseEnter += new System.EventHandler(this.label51_MouseEnter);
            this.label51.MouseLeave += new System.EventHandler(this.label51_MouseLeave);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(136, 472);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(82, 24);
            this.label52.TabIndex = 128;
            this.label52.Text = "内存代数";
            this.label52.Visible = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(136, 314);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(72, 27);
            this.label53.TabIndex = 125;
            this.label53.Text = "零件号";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.Location = new System.Drawing.Point(136, 225);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(92, 27);
            this.label54.TabIndex = 124;
            this.label54.Text = "内存总量";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.Location = new System.Drawing.Point(136, 270);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(72, 27);
            this.label55.TabIndex = 123;
            this.label55.Text = "序列号";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(136, 180);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(92, 27);
            this.label57.TabIndex = 121;
            this.label57.Text = "内存容量";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(136, 136);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(92, 27);
            this.label58.TabIndex = 120;
            this.label58.Text = "内存频率";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(136, 91);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(92, 27);
            this.label59.TabIndex = 119;
            this.label59.Text = "内存厂商";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.label33);
            this.panel7.Controls.Add(this.label48);
            this.panel7.Controls.Add(this.label49);
            this.panel7.Controls.Add(this.label61);
            this.panel7.Controls.Add(this.label63);
            this.panel7.Controls.Add(this.label64);
            this.panel7.Controls.Add(this.label65);
            this.panel7.Location = new System.Drawing.Point(1163, 871);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1015, 610);
            this.panel7.TabIndex = 128;
            this.panel7.Visible = false;
            this.panel7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(136, 314);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 27);
            this.label33.TabIndex = 132;
            this.label33.Text = "状态";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(136, 270);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(72, 27);
            this.label48.TabIndex = 131;
            this.label48.Text = "热插拔";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.White;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(940, 5);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(46, 24);
            this.label49.TabIndex = 129;
            this.label49.Text = "返回";
            this.label49.Click += new System.EventHandler(this.label49_Click);
            this.label49.MouseEnter += new System.EventHandler(this.label49_MouseEnter);
            this.label49.MouseLeave += new System.EventHandler(this.label49_MouseLeave);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label61.Location = new System.Drawing.Point(136, 225);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(52, 27);
            this.label61.TabIndex = 124;
            this.label61.Text = "类名";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(136, 180);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(73, 27);
            this.label63.TabIndex = 121;
            this.label63.Text = "主板ID";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.Location = new System.Drawing.Point(136, 136);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(92, 27);
            this.label64.TabIndex = 120;
            this.label64.Text = "主板型号";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(136, 91);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(92, 27);
            this.label65.TabIndex = 119;
            this.label65.Text = "主板厂商";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.textBox12);
            this.panel11.Controls.Add(this.label76);
            this.panel11.Controls.Add(this.label78);
            this.panel11.Location = new System.Drawing.Point(2242, 793);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1013, 498);
            this.panel11.TabIndex = 132;
            this.panel11.Visible = false;
            this.panel11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.White;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.CausesValidation = false;
            this.textBox12.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox12.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox12.ForeColor = System.Drawing.Color.Black;
            this.textBox12.Location = new System.Drawing.Point(253, 81);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox12.Size = new System.Drawing.Size(749, 524);
            this.textBox12.TabIndex = 132;
            this.textBox12.TabStop = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.White;
            this.label76.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label76.Location = new System.Drawing.Point(940, 5);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(46, 24);
            this.label76.TabIndex = 129;
            this.label76.Text = "返回";
            this.label76.Click += new System.EventHandler(this.label76_Click);
            this.label76.MouseEnter += new System.EventHandler(this.label76_MouseEnter);
            this.label76.MouseLeave += new System.EventHandler(this.label76_MouseLeave);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label78.Location = new System.Drawing.Point(136, 81);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(97, 27);
            this.label78.TabIndex = 119;
            this.label78.Text = "网卡信息:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.label60);
            this.panel8.Controls.Add(this.label67);
            this.panel8.Controls.Add(this.label68);
            this.panel8.Controls.Add(this.label69);
            this.panel8.Controls.Add(this.label70);
            this.panel8.Controls.Add(this.label71);
            this.panel8.Location = new System.Drawing.Point(24, 859);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1015, 610);
            this.panel8.TabIndex = 129;
            this.panel8.Visible = false;
            this.panel8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.White;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(940, 5);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(46, 24);
            this.label60.TabIndex = 129;
            this.label60.Text = "返回";
            this.label60.Click += new System.EventHandler(this.label60_Click);
            this.label60.MouseEnter += new System.EventHandler(this.label60_MouseEnter);
            this.label60.MouseLeave += new System.EventHandler(this.label60_MouseLeave);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(136, 225);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(92, 27);
            this.label67.TabIndex = 124;
            this.label67.Text = "规格型号";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(136, 270);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(92, 27);
            this.label68.TabIndex = 123;
            this.label68.Text = "驱动版本";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(136, 180);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(92, 27);
            this.label69.TabIndex = 121;
            this.label69.Text = "像素比特";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(136, 136);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(92, 27);
            this.label70.TabIndex = 120;
            this.label70.Text = "显示频率";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(136, 91);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(92, 27);
            this.label71.TabIndex = 119;
            this.label71.Text = "显卡型号";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.textBox11);
            this.panel9.Controls.Add(this.textBox10);
            this.panel9.Controls.Add(this.label75);
            this.panel9.Controls.Add(this.label56);
            this.panel9.Controls.Add(this.label62);
            this.panel9.Controls.Add(this.label66);
            this.panel9.Controls.Add(this.label72);
            this.panel9.Controls.Add(this.label73);
            this.panel9.Controls.Add(this.label74);
            this.panel9.Location = new System.Drawing.Point(51, 781);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1015, 624);
            this.panel9.TabIndex = 130;
            this.panel9.Visible = false;
            this.panel9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.CausesValidation = false;
            this.textBox11.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox11.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox11.Location = new System.Drawing.Point(265, 402);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox11.Size = new System.Drawing.Size(747, 213);
            this.textBox11.TabIndex = 133;
            this.textBox11.TabStop = false;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.White;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.CausesValidation = false;
            this.textBox10.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox10.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox10.ForeColor = System.Drawing.Color.Black;
            this.textBox10.Location = new System.Drawing.Point(267, 285);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox10.Size = new System.Drawing.Size(746, 113);
            this.textBox10.TabIndex = 132;
            this.textBox10.TabStop = false;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.Location = new System.Drawing.Point(136, 402);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(97, 27);
            this.label75.TabIndex = 131;
            this.label75.Text = "磁盘分区:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.White;
            this.label56.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.Location = new System.Drawing.Point(940, 5);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(46, 24);
            this.label56.TabIndex = 129;
            this.label56.Text = "返回";
            this.label56.Click += new System.EventHandler(this.label56_Click);
            this.label56.MouseEnter += new System.EventHandler(this.label56_MouseEnter);
            this.label56.MouseLeave += new System.EventHandler(this.label56_MouseEnter);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.Location = new System.Drawing.Point(136, 191);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(92, 27);
            this.label62.TabIndex = 124;
            this.label62.Text = "磁盘状态";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(136, 236);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(92, 27);
            this.label66.TabIndex = 123;
            this.label66.Text = "磁盘序列";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.Location = new System.Drawing.Point(136, 148);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(92, 27);
            this.label72.TabIndex = 121;
            this.label72.Text = "磁盘容量";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label73.Location = new System.Drawing.Point(136, 102);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 27);
            this.label73.TabIndex = 120;
            this.label73.Text = "接口类型";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.Location = new System.Drawing.Point(136, 281);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(97, 27);
            this.label74.TabIndex = 119;
            this.label74.Text = "硬盘名称:";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.textBox13);
            this.panel10.Controls.Add(this.label88);
            this.panel10.Controls.Add(this.label84);
            this.panel10.Controls.Add(this.label87);
            this.panel10.Controls.Add(this.label86);
            this.panel10.Controls.Add(this.label77);
            this.panel10.Controls.Add(this.label82);
            this.panel10.Location = new System.Drawing.Point(1134, 900);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1015, 610);
            this.panel10.TabIndex = 131;
            this.panel10.Visible = false;
            this.panel10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.White;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.CausesValidation = false;
            this.textBox13.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox13.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox13.ForeColor = System.Drawing.Color.Black;
            this.textBox13.Location = new System.Drawing.Point(255, 191);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox13.Size = new System.Drawing.Size(749, 414);
            this.textBox13.TabIndex = 132;
            this.textBox13.TabStop = false;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label88.Location = new System.Drawing.Point(251, 148);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(27, 27);
            this.label88.TabIndex = 136;
            this.label88.Text = "...";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(251, 102);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(27, 27);
            this.label84.TabIndex = 135;
            this.label84.Text = "...";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.Location = new System.Drawing.Point(136, 148);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(97, 27);
            this.label87.TabIndex = 135;
            this.label87.Text = "声卡型号:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.Location = new System.Drawing.Point(136, 102);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(97, 27);
            this.label86.TabIndex = 134;
            this.label86.Text = "声卡型号:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.White;
            this.label77.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(940, 5);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(46, 24);
            this.label77.TabIndex = 129;
            this.label77.Text = "返回";
            this.label77.Click += new System.EventHandler(this.label77_Click);
            this.label77.MouseEnter += new System.EventHandler(this.label77_MouseEnter);
            this.label77.MouseLeave += new System.EventHandler(this.label77_MouseLeave);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(136, 191);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(97, 27);
            this.label82.TabIndex = 119;
            this.label82.Text = "声卡型号:";
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // 定时烤鸡
            // 
            this.定时烤鸡.Interval = 1000;
            this.定时烤鸡.Tick += new System.EventHandler(this.定时烤鸡_Tick);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label83.Font = new System.Drawing.Font("微软雅黑", 10.8F);
            this.label83.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label83.Location = new System.Drawing.Point(1314, 73);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(172, 24);
            this.label83.TabIndex = 133;
            this.label83.Text = "点此下载完整版软件";
            this.label83.Click += new System.EventHandler(this.label83_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.button25);
            this.panel14.Controls.Add(this.烤GPU);
            this.panel14.Controls.Add(this.labl关机);
            this.panel14.Controls.Add(this.烤CPU);
            this.panel14.Controls.Add(this.button2);
            this.panel14.Controls.Add(this.button3);
            this.panel14.Controls.Add(this.radioButton4);
            this.panel14.Controls.Add(this.button4);
            this.panel14.Controls.Add(this.comboBox4);
            this.panel14.Controls.Add(this.button6);
            this.panel14.Controls.Add(this.comboBox5);
            this.panel14.Controls.Add(this.button7);
            this.panel14.Controls.Add(this.comboBox6);
            this.panel14.Controls.Add(this.button8);
            this.panel14.Controls.Add(this.label100);
            this.panel14.Controls.Add(this.button9);
            this.panel14.Controls.Add(this.label101);
            this.panel14.Controls.Add(this.label102);
            this.panel14.Controls.Add(this.label99);
            this.panel14.Controls.Add(this.button10);
            this.panel14.Controls.Add(this.一键双烤);
            this.panel14.Controls.Add(this.button11);
            this.panel14.Controls.Add(this.button5);
            this.panel14.Controls.Add(this.button12);
            this.panel14.Controls.Add(this.button16);
            this.panel14.Controls.Add(this.button13);
            this.panel14.Controls.Add(this.label98);
            this.panel14.Controls.Add(this.label92);
            this.panel14.Controls.Add(this.button27);
            this.panel14.Controls.Add(this.button14);
            this.panel14.Controls.Add(this.button15);
            this.panel14.Controls.Add(this.button26);
            this.panel14.Controls.Add(this.button17);
            this.panel14.Controls.Add(this.button18);
            this.panel14.Controls.Add(this.label96);
            this.panel14.Controls.Add(this.button19);
            this.panel14.Controls.Add(this.button24);
            this.panel14.Controls.Add(this.button20);
            this.panel14.Controls.Add(this.button23);
            this.panel14.Controls.Add(this.button21);
            this.panel14.Controls.Add(this.button22);
            this.panel14.Location = new System.Drawing.Point(1275, 141);
            this.panel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1028, 623);
            this.panel14.TabIndex = 160;
            this.panel14.Visible = false;
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(136, 275);
            this.button25.Margin = new System.Windows.Forms.Padding(4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(110, 30);
            this.button25.TabIndex = 220;
            this.button25.Text = "窗口工具";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.BackColor = System.Drawing.Color.White;
            this.label105.Font = new System.Drawing.Font("微软雅黑", 10.8F);
            this.label105.ForeColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(1474, 21);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(100, 24);
            this.label105.TabIndex = 137;
            this.label105.Text = "CPU使用率";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(4571, 1172);
            this.ControlBox = false;
            this.Controls.Add(this.label105);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label90);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RM Toolbox";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.菜单.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.透明度)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.滑标)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.最小化托盘)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.关闭)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.最小化)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip 菜单;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清空ToolStripMenuItem;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ListView listView6;
        private System.Windows.Forms.ListView listView7;
        private System.Windows.Forms.ListView listView8;
        private System.Windows.Forms.Label label3;

        private System.Windows.Forms.PictureBox 最小化;
        private System.Windows.Forms.PictureBox 关闭;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TrackBar 透明度;
        private System.Windows.Forms.ImageList imageList13;
        private System.Windows.Forms.ImageList imageList6;
        private System.Windows.Forms.ImageList imageList5;
        private System.Windows.Forms.ImageList imageList4;
        private System.Windows.Forms.ImageList imageList3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList21;
        private System.Windows.Forms.ImageList imageList20;
        private System.Windows.Forms.ImageList imageList19;
        private System.Windows.Forms.ImageList imageList18;
        private System.Windows.Forms.ImageList imageList12;
        private System.Windows.Forms.ImageList imageList11;
        private System.Windows.Forms.ImageList imageList10;
        private System.Windows.Forms.ImageList imageList9;
        private System.Windows.Forms.ImageList imageList8;
        private System.Windows.Forms.ImageList imageList7;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.PictureBox 最小化托盘;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listView9;
        private System.Windows.Forms.ListView listView10;
        private System.Windows.Forms.ListView listView11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox 滑标;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label 最新版本;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label 当前版本;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label JieShao;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox 语言选择框;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox 窗口置顶;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.ToolStripMenuItem 大图标ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 中图标ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 小图标ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Panel panel13;
        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.ToolStripMenuItem 打开文件目录toolStripMenuItem1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label 系统状态;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Button 一键双烤;
        private System.Windows.Forms.Label labl关机;
        private System.Windows.Forms.CheckBox radioButton4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Timer 定时烤鸡;
        private System.Windows.Forms.CheckBox 烤GPU;
        private System.Windows.Forms.CheckBox 烤CPU;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.ToolStripMenuItem 删除路径及文件toolStripMenuItem1;
        private System.Windows.Forms.Label label105;
    }
}

