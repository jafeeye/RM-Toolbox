﻿namespace 入梦工具箱
{
    internal class Properties
    {
        public static object Resources { get; internal set; }
    }
}