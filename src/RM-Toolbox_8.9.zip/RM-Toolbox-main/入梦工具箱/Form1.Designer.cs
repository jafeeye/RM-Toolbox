﻿namespace 入梦工具箱
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.菜单 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清空ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.透明度 = new System.Windows.Forms.TrackBar();
            this.窗口置顶 = new System.Windows.Forms.CheckBox();
            this.imageList13 = new System.Windows.Forms.ImageList(this.components);
            this.imageList6 = new System.Windows.Forms.ImageList(this.components);
            this.imageList5 = new System.Windows.Forms.ImageList(this.components);
            this.imageList4 = new System.Windows.Forms.ImageList(this.components);
            this.imageList3 = new System.Windows.Forms.ImageList(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList21 = new System.Windows.Forms.ImageList(this.components);
            this.imageList20 = new System.Windows.Forms.ImageList(this.components);
            this.imageList19 = new System.Windows.Forms.ImageList(this.components);
            this.imageList18 = new System.Windows.Forms.ImageList(this.components);
            this.imageList12 = new System.Windows.Forms.ImageList(this.components);
            this.imageList11 = new System.Windows.Forms.ImageList(this.components);
            this.imageList10 = new System.Windows.Forms.ImageList(this.components);
            this.imageList9 = new System.Windows.Forms.ImageList(this.components);
            this.imageList8 = new System.Windows.Forms.ImageList(this.components);
            this.imageList7 = new System.Windows.Forms.ImageList(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.滑标 = new System.Windows.Forms.PictureBox();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.listView11 = new System.Windows.Forms.ListView();
            this.label28 = new System.Windows.Forms.Label();
            this.listView10 = new System.Windows.Forms.ListView();
            this.listView9 = new System.Windows.Forms.ListView();
            this.listView8 = new System.Windows.Forms.ListView();
            this.listView7 = new System.Windows.Forms.ListView();
            this.listView6 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.listView3 = new System.Windows.Forms.ListView();
            this.listView5 = new System.Windows.Forms.ListView();
            this.listView4 = new System.Windows.Forms.ListView();
            this.listView2 = new System.Windows.Forms.ListView();
            this.label20 = new System.Windows.Forms.Label();
            this.最小化托盘 = new System.Windows.Forms.PictureBox();
            this.关闭 = new System.Windows.Forms.PictureBox();
            this.最小化 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.当前版本 = new System.Windows.Forms.Label();
            this.最新版本 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.菜单.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.透明度)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.滑标)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.最小化托盘)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.关闭)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.最小化)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // 菜单
            // 
            this.菜单.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.菜单.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.删除ToolStripMenuItem,
            this.清空ToolStripMenuItem});
            this.菜单.Name = "contextMenuStrip1";
            this.菜单.Size = new System.Drawing.Size(109, 52);
            this.菜单.Opening += new System.ComponentModel.CancelEventHandler(this.菜单_Opening);
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click_1);
            // 
            // 清空ToolStripMenuItem
            // 
            this.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem";
            this.清空ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.清空ToolStripMenuItem.Text = "清空";
            this.清空ToolStripMenuItem.Click += new System.EventHandler(this.清空ToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(277, 232);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "透明度:";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(595, 297);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 30);
            this.button2.TabIndex = 59;
            this.button2.Text = "系统音频";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // 透明度
            // 
            this.透明度.LargeChange = 10;
            this.透明度.Location = new System.Drawing.Point(376, 226);
            this.透明度.Margin = new System.Windows.Forms.Padding(4);
            this.透明度.Maximum = 100;
            this.透明度.Minimum = 30;
            this.透明度.Name = "透明度";
            this.透明度.Size = new System.Drawing.Size(319, 56);
            this.透明度.TabIndex = 47;
            this.透明度.Value = 100;
            this.透明度.Scroll += new System.EventHandler(this.透明度_Scroll);
            // 
            // 窗口置顶
            // 
            this.窗口置顶.AutoSize = true;
            this.窗口置顶.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.窗口置顶.Location = new System.Drawing.Point(282, 170);
            this.窗口置顶.Margin = new System.Windows.Forms.Padding(4);
            this.窗口置顶.Name = "窗口置顶";
            this.窗口置顶.Size = new System.Drawing.Size(110, 29);
            this.窗口置顶.TabIndex = 46;
            this.窗口置顶.Text = "窗口置顶";
            this.窗口置顶.UseVisualStyleBackColor = true;
            this.窗口置顶.CheckedChanged += new System.EventHandler(this.窗口置顶_CheckedChanged);
            // 
            // imageList13
            // 
            this.imageList13.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList13.ImageStream")));
            this.imageList13.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList13.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList6
            // 
            this.imageList6.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList6.ImageStream")));
            this.imageList6.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList6.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList5
            // 
            this.imageList5.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList5.ImageStream")));
            this.imageList5.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList5.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList4
            // 
            this.imageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList4.ImageStream")));
            this.imageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList4.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList3
            // 
            this.imageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList3.ImageStream")));
            this.imageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList3.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList21
            // 
            this.imageList21.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList21.ImageStream")));
            this.imageList21.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList21.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList20
            // 
            this.imageList20.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList20.ImageStream")));
            this.imageList20.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList20.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList19
            // 
            this.imageList19.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList19.ImageStream")));
            this.imageList19.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList19.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList18
            // 
            this.imageList18.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList18.ImageStream")));
            this.imageList18.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList18.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList12
            // 
            this.imageList12.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList12.ImageStream")));
            this.imageList12.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList12.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList11
            // 
            this.imageList11.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList11.ImageStream")));
            this.imageList11.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList11.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList10
            // 
            this.imageList10.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList10.ImageStream")));
            this.imageList10.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList10.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList9
            // 
            this.imageList9.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList9.ImageStream")));
            this.imageList9.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList9.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList8
            // 
            this.imageList8.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList8.ImageStream")));
            this.imageList8.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList8.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // imageList7
            // 
            this.imageList7.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList7.ImageStream")));
            this.imageList7.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList7.Images.SetKeyName(0, "QQ截图20201003021030.png");
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "入梦工具箱";
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.显示托盘);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel1.Controls.Add(this.pictureBox13);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.滑标);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.pictureBox14);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox11);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox12);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1267, 751);
            this.panel1.TabIndex = 45;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImage = global::入梦语音包.Properties.Resources._1;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Location = new System.Drawing.Point(25, 25);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(70, 70);
            this.pictureBox13.TabIndex = 95;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.pictureBox13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.pictureBox13.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label29.Location = new System.Drawing.Point(102, 71);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(55, 27);
            this.label29.TabIndex = 94;
            this.label29.Text = "V1.0";
            // 
            // 滑标
            // 
            this.滑标.BackColor = System.Drawing.Color.DodgerBlue;
            this.滑标.Location = new System.Drawing.Point(0, 165);
            this.滑标.Name = "滑标";
            this.滑标.Size = new System.Drawing.Size(5, 45);
            this.滑标.TabIndex = 67;
            this.滑标.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label27.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(68, 173);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(88, 25);
            this.label27.TabIndex = 85;
            this.label27.Text = "硬件信息";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pictureBox14.Location = new System.Drawing.Point(0, 165);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(232, 45);
            this.pictureBox14.TabIndex = 84;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(20, 122);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 25);
            this.label18.TabIndex = 83;
            this.label18.Text = "admin:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label16.Location = new System.Drawing.Point(102, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 27);
            this.label16.TabIndex = 81;
            this.label16.Text = "入梦工具箱";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(68, 714);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 25);
            this.label15.TabIndex = 79;
            this.label15.Text = "选项设置";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(68, 669);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 25);
            this.label14.TabIndex = 78;
            this.label14.Text = "自定工具";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(67, 624);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 25);
            this.label13.TabIndex = 77;
            this.label13.Text = "其他工具";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(68, 580);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 25);
            this.label12.TabIndex = 76;
            this.label12.Text = "烤机工具";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(68, 534);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 25);
            this.label11.TabIndex = 75;
            this.label11.Text = "外设工具";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(68, 491);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 25);
            this.label10.TabIndex = 74;
            this.label10.Text = "综合检测";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(69, 445);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 25);
            this.label9.TabIndex = 73;
            this.label9.Text = "屏幕工具";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(68, 400);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 25);
            this.label8.TabIndex = 72;
            this.label8.Text = "硬盘工具";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(68, 355);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 25);
            this.label7.TabIndex = 71;
            this.label7.Text = "显卡工具";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(68, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 25);
            this.label6.TabIndex = 70;
            this.label6.Text = "内存工具";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(67, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 25);
            this.label5.TabIndex = 69;
            this.label5.Text = "主板工具";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(68, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 25);
            this.label4.TabIndex = 68;
            this.label4.Text = "CPU工具";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.SystemColors.MenuBar;
            this.pictureBox9.Location = new System.Drawing.Point(0, 210);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(232, 45);
            this.pictureBox9.TabIndex = 66;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(0, 705);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(232, 45);
            this.pictureBox10.TabIndex = 65;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 255);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(232, 45);
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(0, 570);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(232, 45);
            this.pictureBox5.TabIndex = 66;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(0, 300);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(232, 45);
            this.pictureBox2.TabIndex = 60;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(0, 660);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(232, 45);
            this.pictureBox11.TabIndex = 64;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(0, 345);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(232, 45);
            this.pictureBox4.TabIndex = 61;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(0, 390);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(232, 45);
            this.pictureBox3.TabIndex = 62;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(0, 615);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(232, 45);
            this.pictureBox12.TabIndex = 63;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(0, 435);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(232, 45);
            this.pictureBox8.TabIndex = 63;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(0, 480);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(232, 45);
            this.pictureBox7.TabIndex = 64;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(0, 525);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(232, 45);
            this.pictureBox6.TabIndex = 65;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.listView11);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.listView10);
            this.panel2.Controls.Add(this.listView9);
            this.panel2.Controls.Add(this.listView8);
            this.panel2.Controls.Add(this.listView7);
            this.panel2.Controls.Add(this.listView6);
            this.panel2.Controls.Add(this.listView1);
            this.panel2.Controls.Add(this.listView3);
            this.panel2.Controls.Add(this.listView5);
            this.panel2.Controls.Add(this.listView4);
            this.panel2.Controls.Add(this.listView2);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.最小化托盘);
            this.panel2.Controls.Add(this.关闭);
            this.panel2.Controls.Add(this.最小化);
            this.panel2.Controls.Add(this.pictureBox15);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(232, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1035, 751);
            this.panel2.TabIndex = 58;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(242, 109);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(45, 25);
            this.label33.TabIndex = 96;
            this.label33.Text = "lag:";
            // 
            // listView11
            // 
            this.listView11.AllowDrop = true;
            this.listView11.BackColor = System.Drawing.Color.Black;
            this.listView11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView11.ContextMenuStrip = this.菜单;
            this.listView11.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView11.ForeColor = System.Drawing.Color.Black;
            this.listView11.HideSelection = false;
            this.listView11.Location = new System.Drawing.Point(983, 55);
            this.listView11.Margin = new System.Windows.Forms.Padding(4);
            this.listView11.Name = "listView11";
            this.listView11.Size = new System.Drawing.Size(44, 25);
            this.listView11.TabIndex = 1;
            this.listView11.UseCompatibleStateImageBehavior = false;
            this.listView11.Visible = false;
            this.listView11.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView11_DragDrop);
            this.listView11.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView11_DragEnter);
            this.listView11.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView11_MouseDoubleClick);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(242, 71);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(62, 27);
            this.label28.TabIndex = 95;
            this.label28.Text = "..........";
            this.label28.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label28.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // listView10
            // 
            this.listView10.AllowDrop = true;
            this.listView10.BackColor = System.Drawing.Color.Black;
            this.listView10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView10.ContextMenuStrip = this.菜单;
            this.listView10.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView10.ForeColor = System.Drawing.Color.Black;
            this.listView10.HideSelection = false;
            this.listView10.Location = new System.Drawing.Point(983, 55);
            this.listView10.Margin = new System.Windows.Forms.Padding(4);
            this.listView10.Name = "listView10";
            this.listView10.Size = new System.Drawing.Size(44, 23);
            this.listView10.TabIndex = 1;
            this.listView10.UseCompatibleStateImageBehavior = false;
            this.listView10.Visible = false;
            this.listView10.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView10_DragDrop);
            this.listView10.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView10_DragEnter);
            this.listView10.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView10_MouseDoubleClick);
            // 
            // listView9
            // 
            this.listView9.AllowDrop = true;
            this.listView9.BackColor = System.Drawing.Color.Black;
            this.listView9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView9.ContextMenuStrip = this.菜单;
            this.listView9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView9.ForeColor = System.Drawing.Color.Black;
            this.listView9.HideSelection = false;
            this.listView9.Location = new System.Drawing.Point(989, 58);
            this.listView9.Margin = new System.Windows.Forms.Padding(4);
            this.listView9.Name = "listView9";
            this.listView9.Size = new System.Drawing.Size(38, 18);
            this.listView9.TabIndex = 1;
            this.listView9.UseCompatibleStateImageBehavior = false;
            this.listView9.Visible = false;
            this.listView9.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView9_DragDrop);
            this.listView9.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView9_DragEnter);
            this.listView9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView9_MouseDoubleClick);
            // 
            // listView8
            // 
            this.listView8.AllowDrop = true;
            this.listView8.BackColor = System.Drawing.Color.Black;
            this.listView8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView8.ContextMenuStrip = this.菜单;
            this.listView8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView8.ForeColor = System.Drawing.Color.Black;
            this.listView8.HideSelection = false;
            this.listView8.Location = new System.Drawing.Point(986, 55);
            this.listView8.Margin = new System.Windows.Forms.Padding(4);
            this.listView8.Name = "listView8";
            this.listView8.Size = new System.Drawing.Size(27, 10);
            this.listView8.TabIndex = 1;
            this.listView8.UseCompatibleStateImageBehavior = false;
            this.listView8.Visible = false;
            this.listView8.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView8_DragDrop);
            this.listView8.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView8_DragEnter);
            this.listView8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView8_MouseDoubleClick);
            // 
            // listView7
            // 
            this.listView7.AllowDrop = true;
            this.listView7.BackColor = System.Drawing.Color.Black;
            this.listView7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView7.ContextMenuStrip = this.菜单;
            this.listView7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView7.ForeColor = System.Drawing.Color.Black;
            this.listView7.HideSelection = false;
            this.listView7.Location = new System.Drawing.Point(983, 58);
            this.listView7.Margin = new System.Windows.Forms.Padding(4);
            this.listView7.Name = "listView7";
            this.listView7.Size = new System.Drawing.Size(44, 10);
            this.listView7.TabIndex = 1;
            this.listView7.UseCompatibleStateImageBehavior = false;
            this.listView7.Visible = false;
            this.listView7.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView7_DragDrop);
            this.listView7.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView7_DragEnter);
            this.listView7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView7_MouseDoubleClick);
            // 
            // listView6
            // 
            this.listView6.AllowDrop = true;
            this.listView6.BackColor = System.Drawing.Color.Black;
            this.listView6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView6.ContextMenuStrip = this.菜单;
            this.listView6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView6.ForeColor = System.Drawing.Color.Black;
            this.listView6.HideSelection = false;
            this.listView6.Location = new System.Drawing.Point(983, 66);
            this.listView6.Margin = new System.Windows.Forms.Padding(4);
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(44, 10);
            this.listView6.TabIndex = 1;
            this.listView6.UseCompatibleStateImageBehavior = false;
            this.listView6.Visible = false;
            this.listView6.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView6_DragDrop);
            this.listView6.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView6_DragEnter);
            this.listView6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView6_MouseDoubleClick);
            // 
            // listView1
            // 
            this.listView1.AllowDrop = true;
            this.listView1.BackColor = System.Drawing.Color.Black;
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.ContextMenuStrip = this.菜单;
            this.listView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView1.ForeColor = System.Drawing.Color.Black;
            this.listView1.HideSelection = false;
            this.listView1.LabelEdit = true;
            this.listView1.Location = new System.Drawing.Point(983, 58);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(44, 10);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.Visible = false;
            this.listView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
            this.listView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // listView3
            // 
            this.listView3.AllowDrop = true;
            this.listView3.BackColor = System.Drawing.Color.Black;
            this.listView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView3.ContextMenuStrip = this.菜单;
            this.listView3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView3.ForeColor = System.Drawing.Color.Black;
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(983, 58);
            this.listView3.Margin = new System.Windows.Forms.Padding(4);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(44, 10);
            this.listView3.TabIndex = 1;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.Visible = false;
            this.listView3.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView3_DragDrop);
            this.listView3.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView3_DragEnter);
            this.listView3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView3_MouseDoubleClick);
            // 
            // listView5
            // 
            this.listView5.AllowDrop = true;
            this.listView5.BackColor = System.Drawing.Color.Black;
            this.listView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView5.ContextMenuStrip = this.菜单;
            this.listView5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView5.ForeColor = System.Drawing.Color.Black;
            this.listView5.HideSelection = false;
            this.listView5.Location = new System.Drawing.Point(983, 58);
            this.listView5.Margin = new System.Windows.Forms.Padding(4);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(44, 10);
            this.listView5.TabIndex = 1;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.Visible = false;
            this.listView5.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView5_DragDrop);
            this.listView5.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView5_DragEnter);
            this.listView5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView5_MouseDoubleClick);
            // 
            // listView4
            // 
            this.listView4.AllowDrop = true;
            this.listView4.BackColor = System.Drawing.Color.Black;
            this.listView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView4.ContextMenuStrip = this.菜单;
            this.listView4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView4.ForeColor = System.Drawing.Color.Black;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(983, 66);
            this.listView4.Margin = new System.Windows.Forms.Padding(4);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(44, 10);
            this.listView4.TabIndex = 1;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.Visible = false;
            this.listView4.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView4_DragDrop);
            this.listView4.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView4_DragEnter);
            this.listView4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView4_MouseDoubleClick);
            // 
            // listView2
            // 
            this.listView2.AllowDrop = true;
            this.listView2.BackColor = System.Drawing.Color.Black;
            this.listView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView2.ContextMenuStrip = this.菜单;
            this.listView2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.listView2.ForeColor = System.Drawing.Color.Black;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(983, 66);
            this.listView2.Margin = new System.Windows.Forms.Padding(4);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(44, 10);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.Visible = false;
            this.listView2.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView2_DragDrop);
            this.listView2.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView2_DragEnter);
            this.listView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView2_MouseDoubleClick);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(859, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 25);
            this.label20.TabIndex = 84;
            this.label20.Text = "lag:";
            this.label20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label20.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // 最小化托盘
            // 
            this.最小化托盘.BackgroundImage = global::入梦语音包.Properties.Resources.最小化托盘常规;
            this.最小化托盘.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.最小化托盘.ErrorImage = null;
            this.最小化托盘.Location = new System.Drawing.Point(923, 4);
            this.最小化托盘.Margin = new System.Windows.Forms.Padding(4);
            this.最小化托盘.Name = "最小化托盘";
            this.最小化托盘.Size = new System.Drawing.Size(32, 30);
            this.最小化托盘.TabIndex = 57;
            this.最小化托盘.TabStop = false;
            this.最小化托盘.Click += new System.EventHandler(this.最小化托盘_Click);
            this.最小化托盘.MouseEnter += new System.EventHandler(this.最小化托盘_MouseEnter);
            this.最小化托盘.MouseLeave += new System.EventHandler(this.最小化托盘_MouseLeave);
            // 
            // 关闭
            // 
            this.关闭.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("关闭.BackgroundImage")));
            this.关闭.Location = new System.Drawing.Point(995, 4);
            this.关闭.Margin = new System.Windows.Forms.Padding(4);
            this.关闭.Name = "关闭";
            this.关闭.Size = new System.Drawing.Size(32, 30);
            this.关闭.TabIndex = 38;
            this.关闭.TabStop = false;
            this.关闭.Click += new System.EventHandler(this.关闭_Click_1);
            this.关闭.MouseEnter += new System.EventHandler(this.常规_点燃);
            this.关闭.MouseLeave += new System.EventHandler(this.常规_离开);
            // 
            // 最小化
            // 
            this.最小化.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("最小化.BackgroundImage")));
            this.最小化.Location = new System.Drawing.Point(959, 4);
            this.最小化.Margin = new System.Windows.Forms.Padding(4);
            this.最小化.Name = "最小化";
            this.最小化.Size = new System.Drawing.Size(32, 30);
            this.最小化.TabIndex = 37;
            this.最小化.TabStop = false;
            this.最小化.Click += new System.EventHandler(this.最小化_Click_1);
            this.最小化.MouseEnter += new System.EventHandler(this.最小化_点燃);
            this.最小化.MouseLeave += new System.EventHandler(this.最小化_MouseLeave);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackgroundImage = global::入梦语音包.Properties.Resources._1;
            this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox15.Location = new System.Drawing.Point(135, 25);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(85, 89);
            this.pictureBox15.TabIndex = 92;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.pictureBox15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.pictureBox15.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(241, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 32);
            this.label19.TabIndex = 84;
            this.label19.Text = "..........";
            this.label19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.label19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.label19.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.textBox5);
            this.panel4.Controls.Add(this.textBox4);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Controls.Add(this.textBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Location = new System.Drawing.Point(2, 137);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1032, 611);
            this.panel4.TabIndex = 94;
            this.panel4.Visible = false;
            this.panel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.CausesValidation = false;
            this.textBox6.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox6.Location = new System.Drawing.Point(169, 361);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(832, 34);
            this.textBox6.TabIndex = 130;
            this.textBox6.TabStop = false;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.White;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.CausesValidation = false;
            this.textBox9.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox9.Location = new System.Drawing.Point(169, 406);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(832, 205);
            this.textBox9.TabIndex = 129;
            this.textBox9.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(62, 406);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 25);
            this.label36.TabIndex = 128;
            this.label36.Text = "分区:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(62, 361);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(57, 27);
            this.label31.TabIndex = 125;
            this.label31.Text = "网卡:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(62, 316);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(57, 27);
            this.label32.TabIndex = 124;
            this.label32.Text = "声卡:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(62, 271);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(57, 27);
            this.label30.TabIndex = 123;
            this.label30.Text = "硬盘:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(62, 226);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 27);
            this.label26.TabIndex = 122;
            this.label26.Text = "显卡:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(62, 181);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 27);
            this.label25.TabIndex = 121;
            this.label25.Text = "主板:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(62, 136);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 27);
            this.label24.TabIndex = 120;
            this.label24.Text = "内存:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(62, 91);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 27);
            this.label23.TabIndex = 119;
            this.label23.Text = "处理器:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(62, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 27);
            this.label22.TabIndex = 118;
            this.label22.Text = "分辨率:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(882, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 25);
            this.label2.TabIndex = 117;
            this.label2.Text = "......";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.White;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.CausesValidation = false;
            this.textBox8.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8.Location = new System.Drawing.Point(169, 269);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(832, 34);
            this.textBox8.TabIndex = 116;
            this.textBox8.TabStop = false;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.CausesValidation = false;
            this.textBox7.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(169, 314);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(832, 34);
            this.textBox7.TabIndex = 115;
            this.textBox7.TabStop = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.CausesValidation = false;
            this.textBox5.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(169, 224);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(832, 34);
            this.textBox5.TabIndex = 113;
            this.textBox5.TabStop = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.CausesValidation = false;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(169, 179);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(832, 34);
            this.textBox4.TabIndex = 112;
            this.textBox4.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.CausesValidation = false;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(169, 134);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(832, 34);
            this.textBox3.TabIndex = 111;
            this.textBox3.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.CausesValidation = false;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(169, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(832, 34);
            this.textBox2.TabIndex = 110;
            this.textBox2.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.CausesValidation = false;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBox1.Location = new System.Drawing.Point(169, 44);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(832, 34);
            this.textBox1.TabIndex = 1;
            this.textBox1.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(1367, 52);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 25);
            this.label34.TabIndex = 126;
            this.label34.Text = "CPU:";
            this.label34.Visible = false;
            // 
            // 当前版本
            // 
            this.当前版本.AutoSize = true;
            this.当前版本.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.当前版本.ForeColor = System.Drawing.Color.Black;
            this.当前版本.Location = new System.Drawing.Point(84, 537);
            this.当前版本.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.当前版本.Name = "当前版本";
            this.当前版本.Size = new System.Drawing.Size(52, 25);
            this.当前版本.TabIndex = 86;
            this.当前版本.Text = "V1.0";
            // 
            // 最新版本
            // 
            this.最新版本.AutoSize = true;
            this.最新版本.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.最新版本.ForeColor = System.Drawing.Color.Black;
            this.最新版本.Location = new System.Drawing.Point(277, 537);
            this.最新版本.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.最新版本.Name = "最新版本";
            this.最新版本.Size = new System.Drawing.Size(52, 25);
            this.最新版本.TabIndex = 28;
            this.最新版本.Text = "V1.0";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.button7);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.当前版本);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Controls.Add(this.窗口置顶);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.透明度);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.最新版本);
            this.panel3.Location = new System.Drawing.Point(1301, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1015, 570);
            this.panel3.TabIndex = 60;
            this.panel3.Visible = false;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标按下);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标移动);
            this.panel3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.窗口移动_鼠标左键弹起);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label21.Location = new System.Drawing.Point(821, 537);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 25);
            this.label21.TabIndex = 99;
            this.label21.Text = "官网";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label17.Location = new System.Drawing.Point(877, 537);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 25);
            this.label17.TabIndex = 98;
            this.label17.Text = "反馈";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(282, 349);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 30);
            this.button6.TabIndex = 97;
            this.button6.Text = "卸载软件";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(440, 349);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 30);
            this.button5.TabIndex = 96;
            this.button5.Text = "设置显示";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(440, 297);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 30);
            this.button4.TabIndex = 95;
            this.button4.Text = "鼠标属性";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(282, 297);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 30);
            this.button3.TabIndex = 94;
            this.button3.Text = "控制面板";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(933, 537);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 25);
            this.label1.TabIndex = 93;
            this.label1.Text = "初始化";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.checkBox1.Location = new System.Drawing.Point(440, 170);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(150, 29);
            this.checkBox1.TabIndex = 60;
            this.checkBox1.Text = "F12显示/隐藏";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(2386, 361);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 100;
            this.button1.Text = "自定义列表";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(595, 348);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 30);
            this.button7.TabIndex = 100;
            this.button7.Text = "任务管理器";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(2810, 938);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "入梦工具箱";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.菜单.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.透明度)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.滑标)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.最小化托盘)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.关闭)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.最小化)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip 菜单;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清空ToolStripMenuItem;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ListView listView6;
        private System.Windows.Forms.ListView listView7;
        private System.Windows.Forms.ListView listView8;
        private System.Windows.Forms.Label label3;

        private System.Windows.Forms.PictureBox 最小化;
        private System.Windows.Forms.PictureBox 关闭;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox 窗口置顶;
        private System.Windows.Forms.TrackBar 透明度;
        private System.Windows.Forms.ImageList imageList13;
        private System.Windows.Forms.ImageList imageList6;
        private System.Windows.Forms.ImageList imageList5;
        private System.Windows.Forms.ImageList imageList4;
        private System.Windows.Forms.ImageList imageList3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList21;
        private System.Windows.Forms.ImageList imageList20;
        private System.Windows.Forms.ImageList imageList19;
        private System.Windows.Forms.ImageList imageList18;
        private System.Windows.Forms.ImageList imageList12;
        private System.Windows.Forms.ImageList imageList11;
        private System.Windows.Forms.ImageList imageList10;
        private System.Windows.Forms.ImageList imageList9;
        private System.Windows.Forms.ImageList imageList8;
        private System.Windows.Forms.ImageList imageList7;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.PictureBox 最小化托盘;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listView9;
        private System.Windows.Forms.ListView listView10;
        private System.Windows.Forms.ListView listView11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox 滑标;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label 最新版本;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label 当前版本;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button7;
    }
}

